-- Psychological Support System - Complete PostgreSQL Schema
-- Generated from the supplied SQL source files in dependency-safe order.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- -----------------------------------------------------------------------------
-- Source: create_Addresses_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Addresses (
    address_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    house_number   VARCHAR(50),
    street_address VARCHAR(225),
    ward          VARCHAR(100),
    city          VARCHAR(100),
    province      VARCHAR(100),
    country       VARCHAR(100),
    postal_code    VARCHAR(20),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Schools_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Schools (
    school_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    school_name  VARCHAR(225) NOT NULL,
    address_id   UUID REFERENCES Addresses(address_id) ON UPDATE CASCADE ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ
);

-- -----------------------------------------------------------------------------
-- Source: create_Parents_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Parents (
    parent_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name   VARCHAR(100) NOT NULL,
    last_name    VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    email       VARCHAR(225),
    date_of_birth         DATE,
    status      VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
    gender      VARCHAR(20),
    address_id   UUID REFERENCES Addresses(address_id) ON UPDATE CASCADE ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Counselors_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Counselors (
    counselor_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    gender         VARCHAR(20),
    phone_number    VARCHAR(20),
    email          VARCHAR(225),
    date_of_birth            DATE,
    role           VARCHAR(30),
    status         VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    specialization VARCHAR(225),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Students_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Students (
    student_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name   VARCHAR(100) NOT NULL,
    last_name    VARCHAR(100) NOT NULL,
    gender      VARCHAR(20),
    phone_number VARCHAR(20)  NOT NULL,
    email       VARCHAR(225),
    date_of_birth         DATE,
    status      VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
    school_id    UUID REFERENCES Schools(school_id) ON UPDATE CASCADE ON DELETE SET NULL,
    address_id   UUID REFERENCES Addresses(address_id) ON UPDATE CASCADE ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Student_Parents_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Student_Parents (
    student_parent_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id    UUID NOT NULL REFERENCES Students(student_id) ON DELETE CASCADE,
    parent_id     UUID NOT NULL REFERENCES Parents(parent_id)   ON DELETE CASCADE,
    relationship VARCHAR(30),
    is_primary    BOOLEAN NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_student_parents_pair UNIQUE (student_id, parent_id)
);


-- -----------------------------------------------------------------------------
-- Source: create_Zalo_Mappings_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Zalo_Mappings (
    zalo_mapping_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    zalo_uid       VARCHAR(100) NOT NULL,
    student_id     UUID REFERENCES students(student_id)     ON DELETE CASCADE,
    counselor_id   UUID REFERENCES counselors(counselor_id) ON DELETE CASCADE,
    role          VARCHAR(30),
    linked_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    unlinked_at    TIMESTAMPTZ,
    CONSTRAINT ck_zalo_mappings_owner CHECK (
        (student_id IS NOT NULL AND counselor_id IS NULL) OR
        (student_id IS NULL AND counselor_id IS NOT NULL)
    )
);


-- -----------------------------------------------------------------------------
-- Source: create_Notifications_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Notifications (
    notification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient_role  VARCHAR(30),
    student_id      UUID REFERENCES Students(student_id)     ON DELETE CASCADE,
    counselor_id    UUID REFERENCES Counselors(counselor_id) ON DELETE CASCADE,
    event_type      VARCHAR(50),
    entity_type     VARCHAR(50),   
    entity_id       UUID,          
    channel        VARCHAR(30),
    message        TEXT,
    status         VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    sent_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- -----------------------------------------------------------------------------
-- Source: create_Counselor_Assignments_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Counselor_Assignments (
    assignment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    status       VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    student_id    UUID NOT NULL REFERENCES Students(student_id) ON DELETE CASCADE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Counselor_Assignment_Records_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Counselor_Assignment_Records (
    assignment_record_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    assigned_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at      TIMESTAMPTZ,
    status       VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    assignment_id UUID NOT NULL REFERENCES Counselor_Assignments(assignment_id) ON DELETE CASCADE,
    counselor_id  UUID NOT NULL REFERENCES Counselors(counselor_id)            ON DELETE RESTRICT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ,
    CONSTRAINT ck_car_ended_after_assigned CHECK (ended_at IS NULL OR ended_at >= assigned_at)
);


-- -----------------------------------------------------------------------------
-- Source: create_Treatment_Plans_table.sql
-- -----------------------------------------------------------------------------
-- Kế hoạch tư vấn (treatment plan) gắn với một học sinh. Mỗi học sinh có thể
-- có nhiều kế hoạch theo thời gian (lịch sử), nhưng thông thường chỉ có một
-- kế hoạch ở trạng thái ACTIVE tại một thời điểm.
CREATE TABLE Treatment_Plans (
    treatment_plan_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id          UUID NOT NULL REFERENCES Students(student_id)     ON DELETE CASCADE,
    goal               TEXT NOT NULL,                         -- mục tiêu tư vấn
    start_date          DATE NOT NULL DEFAULT CURRENT_DATE,     -- ngày bắt đầu
    frequency           VARCHAR(50),                            -- tần suất dự kiến, vd: '1 buổi/tuần'
    proposed_sessions   INT,                                    -- số buổi đề xuất
    price              NUMERIC(12,2),                           -- giá
    status              VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',   -- Active / Completed / Paused
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ,
    CONSTRAINT ck_treatment_plans_status CHECK (
        status IN ('ACTIVE', 'COMPLETED', 'PAUSED')
    ),
    CONSTRAINT ck_treatment_plans_proposed_sessions CHECK (
        proposed_sessions IS NULL OR proposed_sessions > 0
    ),
    CONSTRAINT ck_treatment_plans_price CHECK (
        price IS NULL OR price >= 0
    )
);

-- Đảm bảo mỗi học sinh chỉ có tối đa 1 treatment plan đang ACTIVE cùng lúc.
CREATE UNIQUE INDEX uq_treatment_plans_one_active_per_student
    ON Treatment_Plans (student_id)
    WHERE status = 'ACTIVE';


-- -----------------------------------------------------------------------------
-- Source: create_Counselor_Schedules_table.sql
-- -----------------------------------------------------------------------------
-- Lịch làm việc HÀNG TUẦN (recurring) của counselor: counselor làm những thứ
-- nào trong tuần, mỗi thứ có những slot nào. Mỗi slot quy định cứng là 1 tiếng
-- (slot_end_time tự tính = slot_start_time + 1h). Đây là bảng "khuôn mẫu"
-- (template); các slot cụ thể theo ngày thực tế (TIMESTAMPTZ) được SINH RA từ
-- bảng này vào Availability_Slots (xem function fn_generate_availability_slots).
CREATE TABLE Counselor_Schedules (
    schedule_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    counselor_id      UUID NOT NULL REFERENCES Counselors(counselor_id) ON DELETE CASCADE,
    day_of_week       SMALLINT NOT NULL,        -- 1=Thứ Hai ... 6=Thứ Bảy (không làm việc Chủ Nhật; chuẩn ISO-8601 ISODOW)
    slot_start_time   TIME NOT NULL,             -- giờ bắt đầu slot, vd '08:00:00'
    slot_end_time     TIME GENERATED ALWAYS AS (slot_start_time + INTERVAL '1 hour') STORED, -- mỗi slot = 1 tiếng
    status            VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',  -- ACTIVE / INACTIVE
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,      -- áp dụng lịch này từ ngày nào
    effective_until   DATE,                                    -- NULL = áp dụng đến khi có thay đổi
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ,
    CONSTRAINT ck_counselor_schedules_day_of_week CHECK (
        day_of_week BETWEEN 1 AND 6
    ),
    CONSTRAINT ck_counselor_schedules_status CHECK (
        status IN ('ACTIVE', 'INACTIVE')
    ),
    CONSTRAINT ck_counselor_schedules_effective_range CHECK (
        effective_until IS NULL OR effective_until >= effective_from
    )
);

-- Tránh 1 counselor khai báo trùng 2 slot ACTIVE giống hệt nhau (cùng thứ, cùng giờ bắt đầu).
CREATE UNIQUE INDEX uq_counselor_schedules_active_slot
    ON Counselor_Schedules (counselor_id, day_of_week, slot_start_time)
    WHERE status = 'ACTIVE';


-- -----------------------------------------------------------------------------
-- Source: create_Availability_Slots_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Availability_Slots (
    availability_slot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    counselor_id UUID NOT NULL REFERENCES Counselors(counselor_id) ON DELETE CASCADE,
    status      VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    buffer      INT DEFAULT 0,
    start_time   TIMESTAMPTZ NOT NULL,
    end_time     TIMESTAMPTZ NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_avail_time CHECK (end_time > start_time)
);


-- -----------------------------------------------------------------------------
-- Source: create_Bookings_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Bookings (
    booking_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    start_time          TIMESTAMPTZ NOT NULL,
    end_time            TIMESTAMPTZ NOT NULL,
    booking_source      VARCHAR(30),
    status             VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    student_id          UUID NOT NULL REFERENCES Students(student_id)     ON DELETE CASCADE,
    counselor_id        UUID NOT NULL REFERENCES Counselors(counselor_id) ON DELETE RESTRICT,
    availability_slot_id UUID REFERENCES Availability_Slots(availability_slot_id) ON DELETE SET NULL,
    cancel_reason       TEXT,
	cancelled_at   TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ,
    CONSTRAINT ck_booking_time CHECK (end_time > start_time),
    CONSTRAINT uq_booking_availability_slot UNIQUE (availability_slot_id)
);


-- -----------------------------------------------------------------------------
-- Source: create_Sessions_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Sessions (
    session_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_name VARCHAR(225),
    session_type VARCHAR(30),
    booking_id   UUID NOT NULL REFERENCES Bookings(booking_id) ON DELETE CASCADE,
    started_at   TIMESTAMPTZ,
    ended_at     TIMESTAMPTZ,
    status      VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_session_time CHECK (ended_at IS NULL OR started_at IS NULL OR ended_at >= started_at)
);

-- -----------------------------------------------------------------------------
-- Source: create_Assessments_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Assessments (
    assessment_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id           UUID NOT NULL REFERENCES Students(student_id)     ON DELETE CASCADE,
    counselor_id	     UUID NOT NULL REFERENCES Counselors(counselor_id) ON DELETE RESTRICT,
    session_id           UUID REFERENCES Sessions(session_id)              ON DELETE CASCADE,
    booking_id           UUID REFERENCES Bookings(booking_id)              ON DELETE CASCADE,
    assessment_category  VARCHAR(100),
    outcome             TEXT,
    notes               TEXT,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- -----------------------------------------------------------------------------
-- Source: create_Feedbacks_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Feedbacks (
    feedback_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id   UUID NOT NULL REFERENCES Students(student_id)     ON DELETE CASCADE,
    session_id   UUID NOT NULL REFERENCES Sessions(session_id)     ON DELETE CASCADE,
    counselor_id UUID NOT NULL REFERENCES Counselors(counselor_id) ON DELETE RESTRICT,
    rating      INT,
    comment     TEXT,
    category    VARCHAR(100),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_feedback_rating CHECK (rating IS NULL OR rating BETWEEN 1 AND 5)
);


-- -----------------------------------------------------------------------------
-- Source: create_Tests_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Tests (
    test_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_name  VARCHAR(225) NOT NULL,
    test_type  VARCHAR(50),
    status    VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    platform  VARCHAR(50),
    form_url   TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Test_Assignments_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Test_Assignments (
    test_assignment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id   UUID NOT NULL REFERENCES Students(student_id)     ON DELETE CASCADE,
    counselor_id UUID REFERENCES Counselors(counselor_id)          ON DELETE SET NULL,
    test_id      UUID NOT NULL REFERENCES Tests(test_id)           ON DELETE RESTRICT,
    status      VARCHAR(20) NOT NULL DEFAULT 'ASSIGNED',
    assigned_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ
);


-- -----------------------------------------------------------------------------
-- Source: create_Test_Attempts_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Test_Attempts (
    test_attempt_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_assignment_id  UUID NOT NULL REFERENCES Test_Assignments(test_assignment_id) ON DELETE CASCADE,
    attempt_no         INT,   -- auto assign by trigger fn_set_attempt_no() if NULL
    duration          INT,
    status            VARCHAR(20) NOT NULL DEFAULT 'IN_PROGRESS',
    submitted_at       TIMESTAMPTZ,
    assigned_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ,
    CONSTRAINT ck_attemptno_positive CHECK (attempt_no > 0),
    CONSTRAINT uq_testassignment_attemptno UNIQUE (test_assignment_id, attempt_no)
);


-- -----------------------------------------------------------------------------
-- Source: create_Results_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Results (
    result_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_attempt_id UUID NOT NULL REFERENCES Test_Attempts(test_attempt_id) ON DELETE CASCADE,
    score         NUMERIC,
    category      VARCHAR(100),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ,
    CONSTRAINT uq_result_testattempt UNIQUE (test_attempt_id)
);


-- -----------------------------------------------------------------------------
-- Source: create_Counseling_Requests_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Counseling_Requests (
    counseling_request_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Học sinh mà yêu cầu tư vấn thuộc về
    student_id           UUID NOT NULL
                         REFERENCES Students(student_id)
                         ON DELETE CASCADE,

    -- Nếu phụ huynh là người gửi yêu cầu thì lưu parent_id.
    -- Nếu học sinh tự đăng ký thì parent_id để NULL.
    parent_id            UUID
                         REFERENCES Parents(parent_id)
                         ON DELETE SET NULL,

    requester_role       VARCHAR(20) NOT NULL DEFAULT 'STUDENT',

    -- Thông tin nhu cầu / tình trạng tại thời điểm đăng ký
    counseling_issue     TEXT,
    problem_duration     TEXT,
    previous_counseling  BOOLEAN,
    mood_last_2_weeks    TEXT,
    anxiety_stress_level VARCHAR(50),
    sleep_eating_quality TEXT,
    has_support_person  BOOLEAN,
    self_harm_thoughts   BOOLEAN,

    -- Nhu cầu về hình thức và thời gian tư vấn
    preferred_method     VARCHAR(50),
    preferred_time       VARCHAR(100),
    additional_notes     TEXT,

    -- Trạng thái xử lý yêu cầu
    status               VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    source               VARCHAR(50),

    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ,

    CONSTRAINT ck_counseling_request_requester_role
        CHECK (requester_role IN ('STUDENT', 'PARENT')),

    CONSTRAINT ck_counseling_request_parent
        CHECK (
            (requester_role = 'PARENT' AND parent_id IS NOT NULL)
            OR
            (requester_role = 'STUDENT' AND parent_id IS NULL)
        )
);


CREATE INDEX idx_counseling_requests_student_id
    ON Counseling_Requests(student_id);

CREATE INDEX idx_counseling_requests_parent_id
    ON Counseling_Requests(parent_id);

CREATE INDEX idx_counseling_requests_status
    ON Counseling_Requests(status);

-- -----------------------------------------------------------------------------
-- Source: create_Consents_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Consents (
    consent_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id   UUID NOT NULL REFERENCES Students(student_id) ON DELETE CASCADE,
    parent_id    UUID REFERENCES Parents(parent_id)            ON DELETE SET NULL,
    consent_type VARCHAR(50),
    status      VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    consented_at TIMESTAMPTZ,
    revoked_at   TIMESTAMPTZ,
    source      VARCHAR(50),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ,
    CONSTRAINT ck_consent_revoke_after_consent CHECK (revoked_at IS NULL OR consented_at IS NULL OR revoked_at >= consented_at)
);


-- -----------------------------------------------------------------------------
-- Source: create_History_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE History (
    history_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(50) NOT NULL,
    entity_id   UUID NOT NULL,
    status     VARCHAR(20),
    changed_by  UUID,
    reason     TEXT,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- -----------------------------------------------------------------------------
-- Source: create_Audit_Logs_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Audit_Logs (
    audit_log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_id    UUID,
    actor_role  VARCHAR(30),
    action     VARCHAR(100),
    entity_type VARCHAR(50),
    entity_id   UUID,
    value      TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- -----------------------------------------------------------------------------
-- Source: create_Sync_Jobs_table.sql
-- -----------------------------------------------------------------------------
CREATE TABLE Sync_Jobs (
    sync_job_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system  VARCHAR(50),
    target_system  VARCHAR(50),
    entity_type    VARCHAR(50),
    entity_id      UUID,
    operation     VARCHAR(50),
    status        VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    retry_count    INT NOT NULL DEFAULT 0,
    error_message  TEXT,
    last_attempt_at TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_sync_jobs_retry CHECK (retry_count >= 0)
);


-- -----------------------------------------------------------------------------
-- Authentication and authorization module
-- -----------------------------------------------------------------------------
CREATE TABLE Users (
    user_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email                 VARCHAR(225) NOT NULL,
    password_hash         TEXT NOT NULL,
    status                VARCHAR(20) NOT NULL DEFAULT 'PENDING_VERIFICATION',
    email_verified_at     TIMESTAMPTZ,
    failed_login_attempts INT NOT NULL DEFAULT 0,
    locked_until          TIMESTAMPTZ,
    last_login_at         TIMESTAMPTZ,
    password_changed_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ,
    CONSTRAINT ck_users_email_not_blank CHECK (btrim(email) <> ''),
    CONSTRAINT ck_users_password_hash_not_blank CHECK (btrim(password_hash) <> ''),
    CONSTRAINT ck_users_failed_attempts CHECK (failed_login_attempts >= 0),
    CONSTRAINT ck_users_status CHECK (
        status IN ('PENDING_VERIFICATION', 'ACTIVE', 'LOCKED', 'SUSPENDED', 'DISABLED')
    )
);

-- One account can belong to exactly one domain profile. ADMIN accounts may have
-- no domain profile, so all three foreign keys are nullable.
CREATE TABLE User_Profiles (
    user_profile_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID NOT NULL UNIQUE REFERENCES Users(user_id) ON DELETE CASCADE,
    student_id       UUID UNIQUE REFERENCES Students(student_id) ON DELETE CASCADE,
    parent_id        UUID UNIQUE REFERENCES Parents(parent_id) ON DELETE CASCADE,
    counselor_id     UUID UNIQUE REFERENCES Counselors(counselor_id) ON DELETE CASCADE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ,
    CONSTRAINT ck_user_profiles_single_owner CHECK (
        num_nonnulls(student_id, parent_id, counselor_id) = 1
    )
);

CREATE TABLE Roles (
    role_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_code   VARCHAR(50) NOT NULL UNIQUE,
    role_name   VARCHAR(100) NOT NULL,
    description TEXT,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ
);

CREATE TABLE Permissions (
    permission_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    permission_code VARCHAR(100) NOT NULL UNIQUE,
    permission_name VARCHAR(150) NOT NULL,
    description     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE User_Roles (
    user_role_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    role_id      UUID NOT NULL REFERENCES Roles(role_id) ON DELETE RESTRICT,
    assigned_by  UUID REFERENCES Users(user_id) ON DELETE SET NULL,
    assigned_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at   TIMESTAMPTZ,
    CONSTRAINT uq_user_roles UNIQUE (user_id, role_id),
    CONSTRAINT ck_user_roles_expiry CHECK (expires_at IS NULL OR expires_at > assigned_at)
);

CREATE TABLE Role_Permissions (
    role_permission_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id             UUID NOT NULL REFERENCES Roles(role_id) ON DELETE CASCADE,
    permission_id       UUID NOT NULL REFERENCES Permissions(permission_id) ON DELETE CASCADE,
    granted_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_role_permissions UNIQUE (role_id, permission_id)
);

-- Stores only a hash of the refresh token, never the raw token.
CREATE TABLE Auth_Sessions (
    auth_session_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    refresh_token_hash TEXT NOT NULL UNIQUE,
    ip_address        INET,
    user_agent        TEXT,
    device_name       VARCHAR(150),
    expires_at        TIMESTAMPTZ NOT NULL,
    last_used_at      TIMESTAMPTZ,
    revoked_at        TIMESTAMPTZ,
    revoke_reason     VARCHAR(225),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_auth_sessions_expiry CHECK (expires_at > created_at),
    CONSTRAINT ck_auth_sessions_revoke CHECK (revoked_at IS NULL OR revoked_at >= created_at)
);

CREATE TABLE Email_Verification_Tokens (
    email_verification_token_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    token_hash  TEXT NOT NULL UNIQUE,
    expires_at  TIMESTAMPTZ NOT NULL,
    used_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_email_tokens_expiry CHECK (expires_at > created_at),
    CONSTRAINT ck_email_tokens_used CHECK (used_at IS NULL OR used_at >= created_at)
);

CREATE TABLE Password_Reset_Tokens (
    password_reset_token_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    token_hash  TEXT NOT NULL UNIQUE,
    expires_at  TIMESTAMPTZ NOT NULL,
    used_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_password_tokens_expiry CHECK (expires_at > created_at),
    CONSTRAINT ck_password_tokens_used CHECK (used_at IS NULL OR used_at >= created_at)
);

CREATE TABLE Login_Attempts (
    login_attempt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID REFERENCES Users(user_id) ON DELETE SET NULL,
    attempted_email  VARCHAR(225) NOT NULL,
    was_successful   BOOLEAN NOT NULL,
    failure_reason   VARCHAR(100),
    ip_address       INET,
    user_agent       TEXT,
    attempted_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE User_Agreements (
    user_agreement_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    agreement_type    VARCHAR(50) NOT NULL,
    agreement_version VARCHAR(30) NOT NULL,
    accepted_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at        TIMESTAMPTZ,
    ip_address        INET,
    CONSTRAINT uq_user_agreement_version UNIQUE (user_id, agreement_type, agreement_version),
    CONSTRAINT ck_user_agreement_revoke CHECK (revoked_at IS NULL OR revoked_at >= accepted_at)
);

-- Default application roles used during sign-up and administration.
INSERT INTO Roles (role_code, role_name, description) VALUES
    ('ADMIN', 'Administrator', 'Full system administration'),
    ('COUNSELOR', 'Counselor', 'Counselor portal access'),
    ('STUDENT', 'Student', 'Student portal access'),
    ('PARENT', 'Parent', 'Parent portal access')
ON CONFLICT (role_code) DO NOTHING;


-- -----------------------------------------------------------------------------
-- Source: create_index.sql
-- -----------------------------------------------------------------------------
CREATE INDEX idx_schools_address_id                ON Schools (address_id);
CREATE INDEX idx_parents_address_id                ON Parents (address_id);
CREATE INDEX idx_students_school_id                ON Students (school_id);
CREATE INDEX idx_students_address_id               ON Students (address_id);
CREATE INDEX idx_student_parents_student_id         ON Student_Parents (student_id);
CREATE INDEX idx_student_parents_parent_id          ON Student_Parents (parent_id);
CREATE INDEX idx_zalo_mappings_student_id           ON Zalo_Mappings (student_id);
CREATE INDEX idx_zalo_mappings_counselor_id         ON Zalo_Mappings (counselor_id);
CREATE INDEX idx_notifications_student_id          ON Notifications (student_id);
CREATE INDEX idx_notifications_counselor_id        ON Notifications (counselor_id);
CREATE INDEX idx_notifications_entity             ON Notifications (entity_type, entity_id);
CREATE INDEX idx_counselor_assignments_student_id   ON Counselor_Assignments (student_id);
CREATE INDEX idx_car_assignment_id                 ON Counselor_Assignment_Records (assignment_id);
CREATE INDEX idx_car_counselor_id                  ON Counselor_Assignment_Records (counselor_id);
CREATE INDEX idx_treatment_plans_student_id         ON Treatment_Plans (student_id);
CREATE INDEX idx_treatment_plans_status             ON Treatment_Plans (status);
CREATE INDEX idx_counselor_schedules_counselor_id   ON Counselor_Schedules (counselor_id);
CREATE INDEX idx_counselor_schedules_day_of_week    ON Counselor_Schedules (day_of_week);
CREATE INDEX idx_availability_slots_counselor_id    ON Availability_Slots (counselor_id);
CREATE INDEX idx_bookings_student_id               ON Bookings (student_id);
CREATE INDEX idx_bookings_counselor_id             ON Bookings (counselor_id);
CREATE INDEX idx_sessions_booking_id               ON Sessions (booking_id);
CREATE INDEX idx_assessments_student_id            ON Assessments (student_id);
CREATE INDEX idx_assessments_counselor_id          ON Assessments (counselor_id);
CREATE INDEX idx_assessments_session_id            ON Assessments (session_id);
CREATE INDEX idx_assessments_booking_id            ON Assessments (booking_id);
CREATE INDEX idx_feedbacks_student_id              ON Feedbacks (student_id);
CREATE INDEX idx_feedbacks_session_id              ON Feedbacks (session_id);
CREATE INDEX idx_feedbacks_counselor_id            ON Feedbacks (counselor_id);
CREATE INDEX idx_test_assignments_student_id        ON Test_Assignments (student_id);
CREATE INDEX idx_test_assignments_counselor_id      ON Test_Assignments (counselor_id);
CREATE INDEX idx_test_assignments_test_id           ON Test_Assignments (test_id);
CREATE INDEX idx_test_attempts_test_assignment_id    ON Test_Attempts (test_assignment_id);
CREATE INDEX idx_results_test_attempt_id            ON Results (test_attempt_id);
CREATE INDEX idx_consents_student_id               ON Consents (student_id);
CREATE INDEX idx_consents_parent_id                ON Consents (parent_id);
CREATE INDEX idx_history_entity                   ON History (entity_type, entity_id);
CREATE INDEX idx_audit_logs_entity                 ON Audit_Logs (entity_type, entity_id);
CREATE INDEX idx_audit_logs_actor_id                ON Audit_Logs (actor_id);
CREATE INDEX idx_sync_jobs_entity                  ON Sync_Jobs (entity_type, entity_id);
CREATE INDEX idx_sync_jobs_status                  ON Sync_Jobs (status);
CREATE UNIQUE INDEX uq_users_email_ci              ON Users (lower(btrim(email)));
CREATE INDEX idx_users_status                      ON Users (status);
CREATE INDEX idx_user_roles_user_id                ON User_Roles (user_id);
CREATE INDEX idx_user_roles_role_id                ON User_Roles (role_id);
CREATE INDEX idx_role_permissions_role_id          ON Role_Permissions (role_id);
CREATE INDEX idx_role_permissions_permission_id    ON Role_Permissions (permission_id);
CREATE INDEX idx_auth_sessions_user_id             ON Auth_Sessions (user_id);
CREATE INDEX idx_auth_sessions_expires_at          ON Auth_Sessions (expires_at);
CREATE INDEX idx_email_tokens_user_id              ON Email_Verification_Tokens (user_id);
CREATE INDEX idx_password_tokens_user_id           ON Password_Reset_Tokens (user_id);
CREATE INDEX idx_login_attempts_email_time         ON Login_Attempts (lower(attempted_email), attempted_at DESC);
CREATE INDEX idx_login_attempts_user_id             ON Login_Attempts (user_id);
CREATE INDEX idx_user_agreements_user_id           ON User_Agreements (user_id);


-- -----------------------------------------------------------------------------
-- Source: create_function.sql
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Source: create_function_attempt_no.sql
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_set_attempt_no()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.attempt_no IS NULL THEN
        SELECT COALESCE(MAX(attempt_no), 0) + 1
        INTO NEW.attempt_no
        FROM test_attempts
        WHERE test_assignment_id = NEW.test_assignment_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Source: create_function_bookings.sql
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_check_counselor_overlap()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM Bookings b
        WHERE b.counselor_id = NEW.counselor_id
          AND b.booking_id <> NEW.booking_id
          AND b.status NOT IN ('CANCELLED')
          AND (NEW.start_time, NEW.end_time) OVERLAPS (b.start_time, b.end_time)
    ) THEN
        RAISE EXCEPTION 'Counselor % already has a booking overlapping this time range', NEW.counselor_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Source: create_function_history.sql
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_log_counselor_assignment_history()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
        INSERT INTO History (entity_type, entity_id, status, reason, changed_at)
        VALUES ('counselor_assignments', NEW.assignment_id, NEW.status,
                'Status changed from ' || OLD.status || ' to ' || NEW.status, now());
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Source: create_function_counselor_schedules.sql
-- -----------------------------------------------------------------------------
-- Sinh (generate) các Availability_Slots cụ thể trong khoảng [p_from, p_to]
-- dựa trên lịch làm việc hàng tuần đã khai báo trong Counselor_Schedules.
-- Bỏ qua slot đã tồn tại (không tạo trùng). Trả về số slot mới được tạo.
CREATE OR REPLACE FUNCTION fn_generate_availability_slots(p_from DATE, p_to DATE)
RETURNS INT AS $$
DECLARE
    v_count INT := 0;
BEGIN
    INSERT INTO Availability_Slots (counselor_id, status, start_time, end_time)
    SELECT
        cs.counselor_id,
        'OPEN',
        (d.day + cs.slot_start_time)::TIMESTAMPTZ,
        (d.day + cs.slot_end_time)::TIMESTAMPTZ
    FROM Counselor_Schedules cs
    CROSS JOIN generate_series(p_from::TIMESTAMP, p_to::TIMESTAMP, INTERVAL '1 day') AS d(day)
    WHERE cs.status = 'ACTIVE'
      AND EXTRACT(ISODOW FROM d.day) = cs.day_of_week
      AND d.day::DATE >= cs.effective_from
      AND (cs.effective_until IS NULL OR d.day::DATE <= cs.effective_until)
      AND NOT EXISTS (
          SELECT 1 FROM Availability_Slots av
          WHERE av.counselor_id = cs.counselor_id
            AND av.start_time = (d.day + cs.slot_start_time)::TIMESTAMPTZ
      );
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Source: create_function_treatment_plans.sql
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_log_treatment_plan_history()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
        INSERT INTO History (entity_type, entity_id, status, reason, changed_at)
        VALUES ('treatment_plans', NEW.treatment_plan_id, NEW.status,
                'Status changed from ' || OLD.status || ' to ' || NEW.status, now());
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- Source: create_trigger_updated_at.sql
-- -----------------------------------------------------------------------------
CREATE TRIGGER trg_addresses_updated_at            BEFORE UPDATE ON Addresses                 FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_schools_updated_at              BEFORE UPDATE ON Schools                    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_parents_updated_at              BEFORE UPDATE ON Parents                    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_students_updated_at             BEFORE UPDATE ON Students                   FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_counselors_updated_at           BEFORE UPDATE ON Counselors                 FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_counselor_assignments_updated_at BEFORE UPDATE ON Counselor_Assignments       FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_car_updated_at                  BEFORE UPDATE ON Counselor_Assignment_Records FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_treatment_plans_updated_at      BEFORE UPDATE ON Treatment_Plans             FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_counselor_schedules_updated_at  BEFORE UPDATE ON Counselor_Schedules         FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_bookings_updated_at             BEFORE UPDATE ON Bookings                   FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_tests_updated_at                BEFORE UPDATE ON Tests                      FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_test_assignments_updated_at      BEFORE UPDATE ON Test_Assignments             FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_test_attempts_updated_at         BEFORE UPDATE ON Test_Attempts                FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_results_updated_at              BEFORE UPDATE ON Results                     FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_consents_updated_at             BEFORE UPDATE ON Consents                    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_users_updated_at                BEFORE UPDATE ON Users                       FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_user_profiles_updated_at        BEFORE UPDATE ON User_Profiles               FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
CREATE TRIGGER trg_roles_updated_at                BEFORE UPDATE ON Roles                       FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();


-- -----------------------------------------------------------------------------
-- Source: create_trigger_attempt_no.sql
-- -----------------------------------------------------------------------------
CREATE TRIGGER trg_test_attempts_attempt_no
BEFORE INSERT ON test_attempts
FOR EACH ROW EXECUTE FUNCTION fn_set_attempt_no();

-- -----------------------------------------------------------------------------
-- Source: create_trigger_bookings.sql
-- -----------------------------------------------------------------------------
CREATE TRIGGER trg_bookings_no_overlap
BEFORE INSERT OR UPDATE ON Bookings
FOR EACH ROW EXECUTE FUNCTION fn_check_counselor_overlap();

-- -----------------------------------------------------------------------------
-- Source: create_trigger_history.sql
-- -----------------------------------------------------------------------------
CREATE TRIGGER trg_counselor_assignments_history
AFTER UPDATE ON Counselor_Assignments
FOR EACH ROW EXECUTE FUNCTION fn_log_counselor_assignment_history();

CREATE TRIGGER trg_treatment_plans_history
AFTER UPDATE ON Treatment_Plans
FOR EACH ROW EXECUTE FUNCTION fn_log_treatment_plan_history();


COMMIT;